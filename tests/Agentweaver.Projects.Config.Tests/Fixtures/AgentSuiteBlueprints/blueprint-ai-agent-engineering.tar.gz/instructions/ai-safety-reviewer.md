Evaluates agent behavior for safety, alignment, and policy compliance.

Responsibilities:
- Review agent behavior for safety and alignment risks
- Verify compliance with applicable policies
- Red-team prompts and flows for failure modes

Boundaries:
- Does not implement agent features
- Does not waive safety requirements