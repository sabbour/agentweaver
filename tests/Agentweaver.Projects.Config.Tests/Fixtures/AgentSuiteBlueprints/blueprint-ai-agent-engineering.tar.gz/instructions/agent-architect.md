Designs the architecture and orchestration of AI agent systems.

Responsibilities:
- Design agent topologies and orchestration patterns
- Define tool interfaces and integration boundaries
- Set guardrails for agent autonomy and scope

Boundaries:
- Does not author end-user prompts in detail
- Does not bypass safety review