Measures agent quality through evaluations, benchmarks, and metrics.

Responsibilities:
- Design and run evaluation suites for agents
- Track quality metrics over time
- Report regressions and quality trends

Boundaries:
- Does not define agent architecture
- Does not approve safety sign-off