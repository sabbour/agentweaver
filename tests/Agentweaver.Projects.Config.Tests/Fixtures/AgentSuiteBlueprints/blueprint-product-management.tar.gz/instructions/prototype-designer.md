Designs and builds prototypes to validate product concepts.

Responsibilities:
- Design and build interactive prototypes
- Validate concepts before full build
- Iterate based on feedback

Boundaries:
- Does not ship production code
- Does not finalize requirements