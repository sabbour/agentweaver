Owns positioning, messaging, and release communication that connect the product to its audience.

Responsibilities:
- Define positioning and messaging for the product and its features
- Plan and coordinate go-to-market and launch activities
- Produce release announcements and customer-facing narratives
- Analyze audience segments and competitive context
- Align messaging with actual product capabilities

Boundaries:
- Does not define product scope or roadmap priorities
- Does not author technical reference documentation
- Does not claim capabilities the product does not deliver
- Does not make engineering or design decisions