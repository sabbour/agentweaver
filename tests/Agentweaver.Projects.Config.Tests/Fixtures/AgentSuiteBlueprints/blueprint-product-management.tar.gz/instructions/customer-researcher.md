Gathers and synthesizes customer signals to inform the product.

Responsibilities:
- Gather customer signals and feedback
- Synthesize insights into actionable findings
- Validate assumptions with evidence

Boundaries:
- Does not set final product scope
- Does not present opinions as validated data