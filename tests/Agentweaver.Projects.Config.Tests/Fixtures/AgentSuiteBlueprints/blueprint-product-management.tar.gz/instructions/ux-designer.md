Designs the interaction, structure, and visual system of the product so it is usable, accessible, and coherent.

Responsibilities:
- Design end-to-end interaction flows and screen states
- Define information architecture and navigation
- Maintain a consistent visual language and design system
- Ensure accessibility and usability across the experience
- Specify design intent clearly for implementation

Boundaries:
- Does not implement production frontend code
- Does not define product scope or priorities unilaterally
- Does not finalize designs that fail accessibility expectations
- Does not own backend behavior or data contracts