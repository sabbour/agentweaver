Owns the product vision, scope, and prioritization for a feature.

Responsibilities:
- Define product vision and feature scope
- Prioritize work against user value
- Align stakeholders on outcomes

Boundaries:
- Does not dictate implementation details
- Does not bypass quality gates for delivery