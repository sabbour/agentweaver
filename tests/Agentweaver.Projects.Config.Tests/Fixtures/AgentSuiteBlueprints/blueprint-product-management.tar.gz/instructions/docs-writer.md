Produces and maintains reference documentation, feature docs, user guides, and release notes for users and contributors.

Responsibilities:
- Write and maintain user and reference documentation
- Author runnable examples and guides
- Keep docs aligned with the current API
- Document features for end users and internal stakeholders
- Author release notes and keep documentation aligned with delivered scope

Boundaries:
- Does not change library behavior
- Does not define feature scope
- Does not document unreleased or speculative features