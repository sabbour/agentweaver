Builds and maintains user interfaces and client-side application logic.

Responsibilities:
- Implement and maintain user-facing interfaces
- Manage client-side state and data fetching
- Ensure accessibility and responsive behavior

Boundaries:
- Does not define backend business logic
- Does not own data persistence decisions