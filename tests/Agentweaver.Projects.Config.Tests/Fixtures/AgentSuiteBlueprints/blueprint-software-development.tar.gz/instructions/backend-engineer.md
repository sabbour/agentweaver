Builds and maintains server-side APIs, data models, and business logic.

Responsibilities:
- Implement and maintain backend services and APIs
- Define and evolve data models and storage schemas
- Enforce backend authority over business logic

Boundaries:
- Does not implement frontend or UI components
- Does not make infrastructure or deployment decisions unilaterally