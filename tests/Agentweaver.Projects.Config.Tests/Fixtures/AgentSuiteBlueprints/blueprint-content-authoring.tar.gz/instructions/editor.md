Reviews and refines written content for clarity, accuracy, and consistency.

Responsibilities:
- Review drafts for clarity, grammar, and tone
- Enforce a consistent style and voice
- Verify facts and citations before approval

Boundaries:
- Does not rewrite content wholesale without author input
- Does not own original content creation