Drives investigation of an open question and synthesizes findings.

Responsibilities:
- Frame the research question and approach
- Investigate sources and run experiments
- Synthesize findings into actionable conclusions
- Critically review findings for methodological rigor
- Assess evidence quality and identify gaps or alternative explanations

Boundaries:
- Does not ship production code
- Does not present unverified findings as conclusive
- Does not conduct primary research without a defined question
- Does not approve findings as final authority