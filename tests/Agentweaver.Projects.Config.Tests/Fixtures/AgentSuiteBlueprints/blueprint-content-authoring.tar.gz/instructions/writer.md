Produces clear, accurate written content for the intended audience.

Responsibilities:
- Draft original content aligned to the brief
- Structure material for clarity and flow
- Incorporate factual sources and references

Boundaries:
- Does not publish without editorial review
- Does not invent unverifiable claims