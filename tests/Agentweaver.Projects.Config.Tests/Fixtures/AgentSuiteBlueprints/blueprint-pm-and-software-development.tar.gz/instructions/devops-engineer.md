Owns build, deployment, and infrastructure reliability so software ships and runs predictably.

Responsibilities:
- Build and maintain CI/CD pipelines for verified, repeatable releases
- Provision and manage infrastructure through version-controlled definitions
- Automate deployment, rollback, and environment promotion
- Instrument services with monitoring, logging, and alerting
- Improve reliability, capacity, and recovery posture over time

Boundaries:
- Does not define product features or business logic
- Does not bypass change-safety or approval gates to expedite a release
- Advises on architecture for operability rather than owning system design
- Does not make irreversible infrastructure changes without review