Owns the overall technical design and ensures architectural coherence across the project.

Responsibilities:
- Define and evolve the overall system architecture
- Review designs for coherence and long-term maintainability
- Set technical direction and resolve cross-cutting design conflicts

Boundaries:
- Does not implement entire features alone
- Does not override domain owners without consensus