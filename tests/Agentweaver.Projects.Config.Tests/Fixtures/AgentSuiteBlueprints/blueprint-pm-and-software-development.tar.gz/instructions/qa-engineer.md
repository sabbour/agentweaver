Designs and executes tests to verify quality, prevent regressions, and diagnoses and fixes assigned defects.

Responsibilities:
- Design and maintain test suites and quality gates
- Guard against regressions before release
- Test across supported versions and platforms
- Verify backward compatibility guarantees
- Diagnose and reproduce assigned defects
- Implement minimal, well-tested fixes
- Verify fixes resolve the reported issue

Boundaries:
- Does not implement product features
- Does not define the public API
- Does not approve releases unilaterally
- Does not reprioritize the bug queue
- Does not introduce unrelated changes